import os
from flask import Flask, request, jsonify
from google.cloud import pubsub_v1
import json
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Configure the GCP credentials
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "./key.json"

# Initialize the Pub/Sub client
publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path('nice-plexus-422700-g2', 'my-topic')

@app.route('/publish', methods=['POST'])
def publish_message():
    try:
        message_data = request.json.get('message')
        if not message_data:
            return jsonify({"error": "No message provided"}), 400

        # Convert message to bytes and publish
        future = publisher.publish(topic_path, data=message_data.encode('utf-8'))
        message_id = future.result()

        return jsonify({"message_id": message_id}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)