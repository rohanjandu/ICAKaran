import React, { useState, useEffect } from 'react';
import axios from 'axios';

import './App.css';
import './form.css';

const apiUrl = '104.197.243.14';

function App() {
  const [message, setName] = useState('');
  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = {
      message
    };

    try {
      await axios.post(`http://${apiUrl}/publish`, data, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      alert(`Message sent Successfully...`);

    } catch (error) {
      alert(` Failed.`);
    }

    window.location.reload();
  };

  return (
    <div>
      <div className="form-container">
        <h1>Publish message here</h1>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Enter Message:</label>
            <input
              type="text"
              value={message}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="submit-button">send msg</button>
        </form>
      </div>
    </div>
  );
}

export default App;